function login(){
    var uname = document.getElementById("username");
    var password = document.getElementById("password");

    if(uname.value == "admin" && password.value == "password"){
        alert("Valid User");
    }
    else{
        alert("Invalid user");
    }
};

function doRedirect(href){
    window.location = href;
}





